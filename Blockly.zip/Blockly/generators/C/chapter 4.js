Block Definition: {
  "type": "break",
  "message0": "break",
  "previousStatement": null,
  "colour": 230,
  "tooltip": "Place within a loop or a switch statement to end the process.",
  "helpUrl": "https://www.tutorialspoint.com/cplusplus/cpp_break_statement.htm"
}
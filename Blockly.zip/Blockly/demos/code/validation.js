var workspace;

Blockly.C.validator.init = function (newWorkspace){
	
	if(!workspace){
		workspace = newWorkspace;
	}
	
}